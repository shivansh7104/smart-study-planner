import React from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const WeeklyOverview: React.FC = () => {
  const { state } = usePlanner();
  
  // Order days of the week starting from today
  const today = new Date().getDay(); // 0 = Sunday, 1 = Monday, etc.
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
  // Reorder days to start with today
  const orderedDays = [
    ...daysOfWeek.slice(today),
    ...daysOfWeek.slice(0, today)
  ];
  
  // Calculate total hours and completed hours for each day
  const weeklyData = orderedDays.map(day => {
    const daySchedule = state.schedule.find(d => d.day === day);
    
    if (!daySchedule) {
      return { 
        name: day.substring(0, 3), 
        total: 0, 
        completed: 0,
        isToday: day === daysOfWeek[today]
      };
    }
    
    const totalHours = daySchedule.sessions.reduce(
      (sum, session) => sum + session.duration, 0
    );
    
    const completedHours = daySchedule.sessions
      .filter(session => session.completed)
      .reduce((sum, session) => sum + session.duration, 0);
    
    return {
      name: day.substring(0, 3),
      total: totalHours,
      completed: completedHours,
      isToday: day === daysOfWeek[today]
    };
  });

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Weekly Study Overview</h2>
      
      {state.schedule.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-gray-500">No study schedule created yet.</p>
          <p className="text-sm text-gray-400 mt-2">Generate a schedule to see your weekly overview.</p>
        </div>
      ) : (
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={weeklyData}
              margin={{
                top: 10,
                right: 10,
                left: 0,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="name" 
                tick={{ 
                  fontSize: 12,
                  fontWeight: (tick) => {
                    const item = weeklyData.find(d => d.name === tick);
                    return item?.isToday ? 'bold' : 'normal';
                  },
                  fill: (tick) => {
                    const item = weeklyData.find(d => d.name === tick);
                    return item?.isToday ? '#4f46e5' : '#6b7280';
                  }
                }}
              />
              <YAxis 
                tickFormatter={(value) => `${value}h`}
                tick={{ fontSize: 12 }} 
              />
              <Tooltip 
                formatter={(value) => [`${value} hours`, '']}
                labelFormatter={(label) => {
                  const item = weeklyData.find(d => d.name === label);
                  return item?.isToday ? `${label} (Today)` : label;
                }}
              />
              <Bar dataKey="completed" name="Completed" fill="#4ade80" radius={[4, 4, 0, 0]} />
              <Bar dataKey="total" name="Planned" fill="#a5b4fc" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default WeeklyOverview;