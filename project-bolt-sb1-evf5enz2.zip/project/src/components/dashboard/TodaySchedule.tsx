import React from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { Clock, Check } from 'lucide-react';

const TodaySchedule: React.FC = () => {
  const { state, dispatch } = usePlanner();
  
  // Get today's day of the week
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
  
  // Find today's schedule
  const todaySchedule = state.schedule.find(day => day.day.toLowerCase() === today);
  
  const markSessionComplete = (sessionId: string) => {
    dispatch({ 
      type: 'TOGGLE_SESSION_COMPLETE', 
      payload: { 
        dayId: todaySchedule?.id || '', 
        sessionId 
      } 
    });
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Today's Study Sessions</h2>
      
      {!todaySchedule || todaySchedule.sessions.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-gray-500">No study sessions scheduled for today.</p>
          <p className="text-sm text-gray-400 mt-2">Generate a schedule or add subjects with exams to get started.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {todaySchedule.sessions.map((session) => {
            const subject = state.subjects.find(s => s.id === session.subjectId);
            const topic = subject?.topics.find(t => t.id === session.topicId);
            
            return (
              <div 
                key={session.id} 
                className={`flex items-center p-4 rounded-lg border ${
                  session.completed 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex-shrink-0 mr-4">
                  <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-indigo-600" />
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${session.completed ? 'text-green-800 line-through' : 'text-gray-900'}`}>
                    {subject?.name} {topic && `- ${topic.name}`}
                  </p>
                  <p className="text-sm text-gray-500">
                    {session.startTime} - {session.endTime} ({session.duration} hours)
                  </p>
                </div>
                
                <div>
                  <button
                    onClick={() => markSessionComplete(session.id)}
                    className={`p-2 rounded-full ${
                      session.completed 
                        ? 'bg-green-200 text-green-700 hover:bg-green-300' 
                        : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                    }`}
                  >
                    <Check className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TodaySchedule;