import React from 'react';
import { usePlanner } from '../../context/PlannerContext';

const SubjectProgress: React.FC = () => {
  const { state } = usePlanner();
  
  // Calculate progress for each subject
  const subjectsWithProgress = state.subjects.map(subject => {
    const totalTopics = subject.topics.length;
    
    if (totalTopics === 0) {
      return { ...subject, progress: 0 };
    }
    
    // Count completed sessions for this subject
    const completedSessions = state.schedule
      .flatMap(day => day.sessions)
      .filter(session => 
        session.subjectId === subject.id && 
        session.completed
      ).length;
    
    // Total scheduled sessions for this subject
    const totalSessions = state.schedule
      .flatMap(day => day.sessions)
      .filter(session => session.subjectId === subject.id)
      .length;
    
    const progress = totalSessions > 0 
      ? Math.round((completedSessions / totalSessions) * 100) 
      : 0;
    
    return { ...subject, progress };
  });
  
  // Sort by progress (descending)
  const sortedSubjects = [...subjectsWithProgress]
    .sort((a, b) => b.progress - a.progress);

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Subject Progress</h2>
      
      {sortedSubjects.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-gray-500">No subjects added yet.</p>
          <p className="text-sm text-gray-400 mt-2">Add subjects to track your study progress.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedSubjects.map((subject) => (
            <div key={subject.id} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-700">{subject.name}</span>
                <span className="text-sm font-medium text-gray-700">{subject.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${
                    subject.progress >= 75 
                      ? 'bg-green-500' 
                      : subject.progress >= 50 
                        ? 'bg-blue-500' 
                        : subject.progress >= 25 
                          ? 'bg-yellow-500' 
                          : 'bg-red-500'
                  }`} 
                  style={{ width: `${subject.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SubjectProgress;