import React from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { Calendar } from 'lucide-react';

const UpcomingExams: React.FC = () => {
  const { state } = usePlanner();
  
  // Get all exams from all subjects, flatten into a single array
  const allExams = state.subjects.flatMap(subject => 
    subject.exams.map(exam => ({
      ...exam,
      subjectName: subject.name,
      subjectId: subject.id
    }))
  );
  
  // Sort by date, closest first
  const sortedExams = allExams.sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  // Filter to only show upcoming exams (today or later)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const upcomingExams = sortedExams.filter(exam => 
    new Date(exam.date) >= today
  ).slice(0, 5); // Show only the next 5 exams
  
  // Calculate days until each exam
  const examsWithDaysUntil = upcomingExams.map(exam => {
    const examDate = new Date(exam.date);
    const diffTime = examDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return {
      ...exam,
      daysUntil: diffDays
    };
  });

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Upcoming Exams</h2>
      
      {examsWithDaysUntil.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-gray-500">No upcoming exams.</p>
          <p className="text-sm text-gray-400 mt-2">Add subjects with exam dates to track your upcoming tests.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {examsWithDaysUntil.map((exam) => (
            <div key={exam.id} className="flex items-center p-4 rounded-lg border border-gray-200 hover:bg-gray-50">
              <div className="flex-shrink-0 mr-4">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  exam.daysUntil <= 3 
                    ? 'bg-red-100' 
                    : exam.daysUntil <= 7 
                      ? 'bg-amber-100' 
                      : 'bg-green-100'
                }`}>
                  <Calendar className={`h-5 w-5 ${
                    exam.daysUntil <= 3 
                      ? 'text-red-600' 
                      : exam.daysUntil <= 7 
                        ? 'text-amber-600' 
                        : 'text-green-600'
                  }`} />
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {exam.name}
                </p>
                <p className="text-sm text-gray-500">
                  {exam.subjectName} - {new Date(exam.date).toLocaleDateString()}
                </p>
              </div>
              
              <div className={`ml-4 px-3 py-1 rounded-full text-xs font-medium ${
                exam.daysUntil <= 3 
                  ? 'bg-red-100 text-red-800' 
                  : exam.daysUntil <= 7 
                    ? 'bg-amber-100 text-amber-800' 
                    : 'bg-green-100 text-green-800'
              }`}>
                {exam.daysUntil === 0 
                  ? 'Today!' 
                  : exam.daysUntil === 1 
                    ? 'Tomorrow' 
                    : `${exam.daysUntil} days`}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UpcomingExams;