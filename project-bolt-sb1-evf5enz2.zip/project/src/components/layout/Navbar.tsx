import React, { useState } from 'react';
import { Menu, Bell, User } from 'lucide-react';
import { usePlanner } from '../../context/PlannerContext';

const Navbar: React.FC = () => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const { state } = usePlanner();
  
  const upcomingExams = state.subjects
    .flatMap(subject => subject.exams)
    .filter(exam => {
      const examDate = new Date(exam.date);
      const today = new Date();
      const diffDays = Math.ceil((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 7;
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <header className="bg-white border-b border-gray-200 z-30">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex">
            <button
              type="button"
              className="md:hidden text-gray-500 hover:text-gray-600 focus:outline-none"
            >
              <Menu size={24} />
            </button>
            <div className="hidden md:flex md:items-center">
              <h1 className="text-xl font-semibold text-indigo-600">StudySmart</h1>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <button
                className="flex text-gray-500 hover:text-gray-600 focus:outline-none"
                onClick={() => {}}
              >
                <Bell size={20} />
                {upcomingExams.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4">
                    <span className="animate-ping absolute h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                    <span className="relative flex justify-center items-center rounded-full h-4 w-4 bg-indigo-500 text-xs text-white">
                      {upcomingExams.length}
                    </span>
                  </span>
                )}
              </button>
            </div>

            <div className="relative">
              <button
                className="flex text-gray-500 hover:text-gray-600 focus:outline-none"
                onClick={() => setIsProfileOpen(!isProfileOpen)}
              >
                <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-500">
                  <User size={18} />
                </div>
              </button>
              
              {isProfileOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Your Profile
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Settings
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Sign out
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;