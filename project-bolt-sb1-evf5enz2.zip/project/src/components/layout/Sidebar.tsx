import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, BookOpen, Calendar, Settings, GraduationCap, Clock } from 'lucide-react';

const Sidebar: React.FC = () => {
  const navItems = [
    { name: 'Dashboard', path: '/', icon: <Home size={20} /> },
    { name: 'Subjects', path: '/subjects', icon: <BookOpen size={20} /> },
    { name: 'Schedule', path: '/schedule', icon: <Calendar size={20} /> },
    { name: 'Settings', path: '/settings', icon: <Settings size={20} /> },
  ];

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 bg-indigo-700 text-white">
      <div className="flex items-center justify-center h-16 border-b border-indigo-800">
        <GraduationCap size={28} className="mr-2" />
        <span className="text-xl font-bold">StudySmart</span>
      </div>
      <div className="overflow-y-auto py-4 flex flex-col flex-grow">
        <nav className="mt-5 flex-1 px-2 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-indigo-800 text-white'
                    : 'text-indigo-100 hover:bg-indigo-600'
                }`
              }
            >
              <div className="mr-3">{item.icon}</div>
              {item.name}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 mt-6 border-t border-indigo-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-indigo-300 mr-2" />
              <span className="text-sm font-medium text-indigo-100">Study Progress</span>
            </div>
            <span className="text-sm font-medium text-indigo-100">45%</span>
          </div>
          <div className="mt-2 w-full bg-indigo-600 rounded-full h-2">
            <div className="bg-green-400 h-2 rounded-full" style={{ width: '45%' }}></div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;