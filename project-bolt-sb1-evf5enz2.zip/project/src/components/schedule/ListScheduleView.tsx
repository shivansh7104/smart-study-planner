import React, { useState } from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';

const ListScheduleView: React.FC = () => {
  const { state, dispatch } = usePlanner();
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  
  const toggleDayExpand = (dayId: string) => {
    setExpandedDay(expandedDay === dayId ? null : dayId);
  };
  
  const markSessionComplete = (dayId: string, sessionId: string) => {
    dispatch({ 
      type: 'TOGGLE_SESSION_COMPLETE', 
      payload: { dayId, sessionId } 
    });
  };
  
  const getSessionSubjectInfo = (session: any) => {
    const subject = state.subjects.find(s => s.id === session.subjectId);
    const topic = subject?.topics.find(t => t.id === session.topicId);
    
    return {
      subjectName: subject?.name || 'Unknown Subject',
      topicName: topic?.name,
      color: subject?.color || '#4f46e5'
    };
  };

  // Get current day of week
  const currentDayOfWeek = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  
  // Sort days to start with current day
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const currentDayIndex = daysOfWeek.findIndex(
    day => day === currentDayOfWeek
  );
  
  const orderedDays = [
    ...daysOfWeek.slice(currentDayIndex),
    ...daysOfWeek.slice(0, currentDayIndex)
  ];
  
  // Find the schedule for each day, preserving the new order
  const orderedSchedule = orderedDays
    .map(dayName => {
      return state.schedule.find(day => day.day === dayName);
    })
    .filter(Boolean);

  return (
    <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
      {state.schedule.length === 0 ? (
        <div className="p-6 text-center">
          <p className="text-gray-500">No study schedule generated yet.</p>
          <p className="text-sm text-gray-400 mt-2">Click "Generate Schedule" to create your personalized study plan.</p>
        </div>
      ) : (
        orderedSchedule.map((day) => (
          <div key={day.id} className="px-4 py-4 sm:px-6">
            <div 
              className="flex items-center justify-between cursor-pointer"
              onClick={() => toggleDayExpand(day.id)}
            >
              <div className="flex items-center">
                {expandedDay === day.id ? 
                  <ChevronUp className="h-5 w-5 text-gray-400 mr-2" /> : 
                  <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
                }
                <h3 className={`text-lg font-medium ${
                  day.day === currentDayOfWeek ? 'text-indigo-600' : 'text-gray-900'
                }`}>
                  {day.day}
                  {day.day === currentDayOfWeek && ' (Today)'}
                </h3>
              </div>
              
              <div className="text-sm text-gray-500">
                {day.sessions.length} {day.sessions.length === 1 ? 'session' : 'sessions'} • 
                {' '}{day.sessions.reduce((total, session) => total + session.duration, 0)} hours
              </div>
            </div>
            
            {expandedDay === day.id && (
              <div className="mt-4 space-y-3">
                {day.sessions.length === 0 ? (
                  <p className="text-sm text-gray-500 italic">No study sessions scheduled for this day.</p>
                ) : (
                  day.sessions.map((session) => {
                    const { subjectName, topicName, color } = getSessionSubjectInfo(session);
                    
                    return (
                      <div key={session.id} className="flex items-center">
                        <div 
                          className="w-2 h-full min-h-[40px] rounded-full mr-3"
                          style={{ backgroundColor: color }}
                        ></div>
                        <div className="flex-1 border border-gray-200 rounded-lg p-3 flex justify-between items-center">
                          <div>
                            <div className="flex items-center">
                              <span className="text-sm font-medium text-gray-900">
                                {session.startTime} - {session.endTime}
                              </span>
                              <span className="ml-2 px-2 py-0.5 bg-gray-100 text-gray-800 text-xs rounded-full">
                                {session.duration} {session.duration === 1 ? 'hour' : 'hours'}
                              </span>
                            </div>
                            <p className="text-sm text-gray-700 mt-1">
                              {subjectName}
                              {topicName && <span className="text-gray-500"> - {topicName}</span>}
                            </p>
                          </div>
                          
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              markSessionComplete(day.id, session.id);
                            }}
                            className={`p-2 rounded-full ${
                              session.completed 
                                ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                                : 'bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-500'
                            }`}
                          >
                            <Check className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default ListScheduleView;