import React, { useState } from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const CalendarView: React.FC = () => {
  const { state } = usePlanner();
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Get days in month
  const daysInMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() + 1,
    0
  ).getDate();
  
  // Get first day of month (0 = Sunday, 1 = Monday, etc.)
  const firstDayOfMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    1
  ).getDay();
  
  // Create calendar days array
  const calendarDays = [];
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push({ day: null, date: null });
  }
  
  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    calendarDays.push({ 
      day, 
      date,
      dayOfWeek: date.toLocaleDateString('en-US', { weekday: 'long' }),
      isToday: 
        date.getDate() === new Date().getDate() &&
        date.getMonth() === new Date().getMonth() &&
        date.getFullYear() === new Date().getFullYear()
    });
  }
  
  // Handle month navigation
  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  // Get sessions for a specific date
  const getSessionsForDate = (date: Date) => {
    if (!date) return [];
    
    const dayOfWeek = date.toLocaleDateString('en-US', { weekday: 'long' });
    const daySchedule = state.schedule.find(d => d.day === dayOfWeek);
    
    if (!daySchedule) return [];
    
    return daySchedule.sessions.map(session => {
      const subject = state.subjects.find(s => s.id === session.subjectId);
      const topic = subject?.topics.find(t => t.id === session.topicId);
      
      return {
        ...session,
        subjectName: subject?.name || '',
        topicName: topic?.name || '',
        color: subject?.color || '#4f46e5'
      };
    });
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">
          {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
        </h3>
        <div className="flex space-x-2">
          <button
            onClick={goToPreviousMonth}
            className="inline-flex items-center p-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={() => setCurrentDate(new Date())}
            className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            Today
          </button>
          <button
            onClick={goToNextMonth}
            className="inline-flex items-center p-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-7 gap-px bg-gray-200">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div key={day} className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-500">
            {day}
          </div>
        ))}
        
        {calendarDays.map((day, index) => {
          const sessions = day.date ? getSessionsForDate(day.date) : [];
          
          return (
            <div
              key={index}
              className={`min-h-[100px] p-2 ${
                day.day
                  ? 'bg-white'
                  : 'bg-gray-50'
              } ${
                day.isToday
                  ? 'ring-2 ring-indigo-500 ring-inset'
                  : ''
              }`}
            >
              {day.day && (
                <>
                  <div className={`text-right ${
                    day.isToday
                      ? 'font-bold text-indigo-600'
                      : 'text-gray-700'
                  }`}>
                    {day.day}
                  </div>
                  
                  <div className="mt-1 space-y-1 max-h-20 overflow-y-auto">
                    {sessions.map((session) => (
                      <div
                        key={session.id}
                        className="px-2 py-1 text-xs rounded truncate"
                        style={{ 
                          backgroundColor: `${session.color}20`,
                          borderLeft: `3px solid ${session.color}` 
                        }}
                      >
                        <div className="font-medium" style={{ color: session.color }}>
                          {session.startTime}
                        </div>
                        <div className="truncate text-gray-600">
                          {session.subjectName}
                          {session.topicName && ` - ${session.topicName}`}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CalendarView;