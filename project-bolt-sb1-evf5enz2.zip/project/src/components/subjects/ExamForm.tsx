import React, { useState } from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { X } from 'lucide-react';

interface ExamFormProps {
  subjectId: string;
  onClose: () => void;
}

const ExamForm: React.FC<ExamFormProps> = ({ subjectId, onClose }) => {
  const { dispatch } = usePlanner();
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [weight, setWeight] = useState<number>(1); // 1-3 scale for importance
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !date) return;
    
    dispatch({
      type: 'ADD_EXAM',
      payload: {
        subjectId,
        name,
        date,
        weight
      }
    });
    
    onClose();
  };

  // Calculate min date (today)
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="bg-gray-100 rounded-md p-4 mb-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-medium text-gray-700">Add New Exam</h4>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label htmlFor="exam-name" className="block text-xs font-medium text-gray-700">
            Exam Name
          </label>
          <input
            type="text"
            id="exam-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            placeholder="e.g., Midterm, Final Exam, Quiz 1"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="exam-date" className="block text-xs font-medium text-gray-700">
              Exam Date
            </label>
            <input
              type="date"
              id="exam-date"
              min={today}
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
              required
            />
          </div>
          
          <div>
            <label htmlFor="weight" className="block text-xs font-medium text-gray-700">
              Importance Level
            </label>
            <select
              id="weight"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            >
              <option value={1}>Low Importance</option>
              <option value={2}>Medium Importance</option>
              <option value={3}>High Importance</option>
            </select>
          </div>
        </div>
        
        <div className="flex justify-end space-x-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex justify-center py-1.5 px-3 border border-gray-300 shadow-sm text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-1.5 px-3 border border-transparent shadow-sm text-xs font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            Add Exam
          </button>
        </div>
      </form>
    </div>
  );
};

export default ExamForm;