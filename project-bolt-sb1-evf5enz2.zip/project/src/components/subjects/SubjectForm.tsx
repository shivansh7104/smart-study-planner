import React, { useState, useEffect } from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { X } from 'lucide-react';

interface SubjectFormProps {
  onClose: () => void;
  editingId?: string | null;
  onDone?: () => void;
}

const SubjectForm: React.FC<SubjectFormProps> = ({ onClose, editingId, onDone }) => {
  const { state, dispatch } = usePlanner();
  const [name, setName] = useState('');
  const [priority, setPriority] = useState<number>(1);
  const [color, setColor] = useState('#4f46e5');
  
  useEffect(() => {
    if (editingId) {
      const subject = state.subjects.find(s => s.id === editingId);
      if (subject) {
        setName(subject.name);
        setPriority(subject.priority);
        setColor(subject.color || '#4f46e5');
      }
    }
  }, [editingId, state.subjects]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) return;
    
    if (editingId) {
      dispatch({
        type: 'UPDATE_SUBJECT',
        payload: {
          id: editingId,
          name,
          priority,
          color
        }
      });
    } else {
      dispatch({
        type: 'ADD_SUBJECT',
        payload: {
          name,
          priority,
          color
        }
      });
    }
    
    if (onDone) {
      onDone();
    } else {
      onClose();
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-900">
          {editingId ? 'Edit Subject' : 'Add New Subject'}
        </h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="subject-name" className="block text-sm font-medium text-gray-700">
            Subject Name
          </label>
          <input
            type="text"
            id="subject-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., Mathematics, Biology, History"
            required
          />
        </div>
        
        <div>
          <label htmlFor="priority" className="block text-sm font-medium text-gray-700">
            Priority Level (1-5)
          </label>
          <select
            id="priority"
            value={priority}
            onChange={(e) => setPriority(Number(e.target.value))}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value={1}>1 - Low Priority</option>
            <option value={2}>2 - Somewhat Important</option>
            <option value={3}>3 - Important</option>
            <option value={4}>4 - Very Important</option>
            <option value={5}>5 - Highest Priority</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="color" className="block text-sm font-medium text-gray-700">
            Subject Color
          </label>
          <div className="mt-1 flex items-center space-x-3">
            <input
              type="color"
              id="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="h-10 w-10 border border-gray-300 rounded-md shadow-sm cursor-pointer"
            />
            <span className="text-sm text-gray-500">
              Choose a color to identify this subject in your schedule
            </span>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {editingId ? 'Update Subject' : 'Add Subject'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default SubjectForm;