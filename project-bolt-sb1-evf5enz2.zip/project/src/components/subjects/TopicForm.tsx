import React, { useState } from 'react';
import { usePlanner } from '../../context/PlannerContext';
import { X } from 'lucide-react';

interface TopicFormProps {
  subjectId: string;
  onClose: () => void;
}

const TopicForm: React.FC<TopicFormProps> = ({ subjectId, onClose }) => {
  const { dispatch } = usePlanner();
  const [name, setName] = useState('');
  const [estimatedHours, setEstimatedHours] = useState(2);
  const [difficulty, setDifficulty] = useState<number>(2); // 1-5 scale
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) return;
    
    dispatch({
      type: 'ADD_TOPIC',
      payload: {
        subjectId,
        name,
        estimatedHours,
        difficulty
      }
    });
    
    onClose();
  };

  return (
    <div className="bg-gray-100 rounded-md p-4 mb-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-medium text-gray-700">Add New Topic</h4>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label htmlFor="topic-name" className="block text-xs font-medium text-gray-700">
            Topic Name
          </label>
          <input
            type="text"
            id="topic-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            placeholder="e.g., Algebra, Thermal Physics, World War II"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="estimated-hours" className="block text-xs font-medium text-gray-700">
              Estimated Study Hours
            </label>
            <input
              type="number"
              id="estimated-hours"
              min={1}
              max={20}
              value={estimatedHours}
              onChange={(e) => setEstimatedHours(Number(e.target.value))}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            />
          </div>
          
          <div>
            <label htmlFor="difficulty" className="block text-xs font-medium text-gray-700">
              Difficulty Level
            </label>
            <select
              id="difficulty"
              value={difficulty}
              onChange={(e) => setDifficulty(Number(e.target.value))}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            >
              <option value={1}>1 - Very Easy</option>
              <option value={2}>2 - Easy</option>
              <option value={3}>3 - Moderate</option>
              <option value={4}>4 - Difficult</option>
              <option value={5}>5 - Very Difficult</option>
            </select>
          </div>
        </div>
        
        <div className="flex justify-end space-x-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex justify-center py-1.5 px-3 border border-gray-300 shadow-sm text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-1.5 px-3 border border-transparent shadow-sm text-xs font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            Add Topic
          </button>
        </div>
      </form>
    </div>
  );
};

export default TopicForm;