import React from 'react';
import { usePlanner } from '../../context/PlannerContext';

const DailyAvailability: React.FC = () => {
  const { state, dispatch } = usePlanner();
  
  const handleAvailabilityChange = (day: string, timeSlot: string, value: boolean) => {
    dispatch({
      type: 'UPDATE_AVAILABILITY',
      payload: {
        day,
        timeSlot,
        value
      }
    });
  };
  
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const timeSlots = [
    { id: 'morning', label: 'Morning (8AM - 12PM)' },
    { id: 'afternoon', label: 'Afternoon (12PM - 5PM)' },
    { id: 'evening', label: 'Evening (5PM - 9PM)' }
  ];

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Time Slot
            </th>
            {daysOfWeek.map((day) => (
              <th key={day} className="px-6 py-3 bg-gray-50 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                {day.substring(0, 3)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {timeSlots.map((timeSlot) => (
            <tr key={timeSlot.id}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {timeSlot.label}
              </td>
              {daysOfWeek.map((day) => {
                const isAvailable = state.availability[day.toLowerCase()]?.[timeSlot.id];
                
                return (
                  <td key={`${day}-${timeSlot.id}`} className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center">
                      <input
                        type="checkbox"
                        id={`${day}-${timeSlot.id}`}
                        checked={isAvailable || false}
                        onChange={(e) => handleAvailabilityChange(
                          day.toLowerCase(),
                          timeSlot.id,
                          e.target.checked
                        )}
                        className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                      />
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      
      <p className="mt-4 text-sm text-gray-500">
        Check the boxes for time slots when you are available to study. The scheduler will use this information to create your personalized study plan.
      </p>
    </div>
  );
};

export default DailyAvailability;