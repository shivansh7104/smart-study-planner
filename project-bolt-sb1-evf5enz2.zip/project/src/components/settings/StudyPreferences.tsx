import React from 'react';
import { usePlanner } from '../../context/PlannerContext';

const StudyPreferences: React.FC = () => {
  const { state, dispatch } = usePlanner();
  
  const handleSessionDurationChange = (value: number) => {
    dispatch({
      type: 'UPDATE_PREFERENCES',
      payload: {
        sessionDuration: value
      }
    });
  };
  
  const handleBreakTimeChange = (value: number) => {
    dispatch({
      type: 'UPDATE_PREFERENCES',
      payload: {
        breakTime: value
      }
    });
  };
  
  const handleMaxSessionsPerDayChange = (value: number) => {
    dispatch({
      type: 'UPDATE_PREFERENCES',
      payload: {
        maxSessionsPerDay: value
      }
    });
  };
  
  const handlePriorityStrategyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    dispatch({
      type: 'UPDATE_PREFERENCES',
      payload: {
        priorityStrategy: e.target.value
      }
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <label htmlFor="session-duration" className="block text-sm font-medium text-gray-700">
          Preferred Study Session Duration (hours)
        </label>
        <input
          type="range"
          id="session-duration"
          min={0.5}
          max={3}
          step={0.5}
          value={state.preferences.sessionDuration}
          onChange={(e) => handleSessionDurationChange(parseFloat(e.target.value))}
          className="mt-2 w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>30min</span>
          <span>1hr</span>
          <span>1.5hr</span>
          <span>2hr</span>
          <span>2.5hr</span>
          <span>3hr</span>
        </div>
        <p className="mt-2 text-sm text-gray-600">
          Current: {state.preferences.sessionDuration} hours
        </p>
      </div>
      
      <div>
        <label htmlFor="break-time" className="block text-sm font-medium text-gray-700">
          Break Time Between Sessions (minutes)
        </label>
        <input
          type="range"
          id="break-time"
          min={5}
          max={30}
          step={5}
          value={state.preferences.breakTime}
          onChange={(e) => handleBreakTimeChange(parseInt(e.target.value))}
          className="mt-2 w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>5min</span>
          <span>10min</span>
          <span>15min</span>
          <span>20min</span>
          <span>25min</span>
          <span>30min</span>
        </div>
        <p className="mt-2 text-sm text-gray-600">
          Current: {state.preferences.breakTime} minutes
        </p>
      </div>
      
      <div>
        <label htmlFor="max-sessions" className="block text-sm font-medium text-gray-700">
          Maximum Study Sessions Per Day
        </label>
        <input
          type="range"
          id="max-sessions"
          min={1}
          max={8}
          step={1}
          value={state.preferences.maxSessionsPerDay}
          onChange={(e) => handleMaxSessionsPerDayChange(parseInt(e.target.value))}
          className="mt-2 w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>4</span>
          <span>5</span>
          <span>6</span>
          <span>7</span>
          <span>8</span>
        </div>
        <p className="mt-2 text-sm text-gray-600">
          Current: {state.preferences.maxSessionsPerDay} sessions
        </p>
      </div>
      
      <div>
        <label htmlFor="priority-strategy" className="block text-sm font-medium text-gray-700">
          Study Priority Strategy
        </label>
        <select
          id="priority-strategy"
          value={state.preferences.priorityStrategy}
          onChange={handlePriorityStrategyChange}
          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="exam-date">Prioritize by Upcoming Exams</option>
          <option value="subject-priority">Prioritize by Subject Importance</option>
          <option value="balanced">Balanced Approach</option>
          <option value="difficulty">Prioritize Difficult Topics First</option>
        </select>
        <p className="mt-2 text-sm text-gray-600">
          This strategy determines how study time is allocated across your subjects.
        </p>
      </div>
    </div>
  );
};

export default StudyPreferences;