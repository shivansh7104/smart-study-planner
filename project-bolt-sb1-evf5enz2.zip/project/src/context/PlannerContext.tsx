import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

// Types

export interface Topic {
  id: string;
  name: string;
  estimatedHours: number;
  difficulty: number;
}

export interface Exam {
  id: string;
  name: string;
  date: string;
  weight: number;
}

export interface Subject {
  id: string;
  name: string;
  priority: number;
  color: string;
  topics: Topic[];
  exams: Exam[];
}

export interface StudySession {
  id: string;
  subjectId: string;
  topicId: string | null;
  startTime: string;
  endTime: string;
  duration: number;
  completed: boolean;
}

export interface DaySchedule {
  id: string;
  day: string;
  sessions: StudySession[];
}

export interface Availability {
  [day: string]: {
    morning?: boolean;
    afternoon?: boolean;
    evening?: boolean;
  };
}

export interface Preferences {
  sessionDuration: number;
  breakTime: number;
  maxSessionsPerDay: number;
  priorityStrategy: string;
}

export interface PlannerState {
  subjects: Subject[];
  schedule: DaySchedule[];
  availability: Availability;
  preferences: Preferences;
}

// Initial state
const initialState: PlannerState = {
  subjects: [],
  schedule: [],
  availability: {
    monday: { morning: true, afternoon: true, evening: true },
    tuesday: { morning: true, afternoon: true, evening: true },
    wednesday: { morning: true, afternoon: true, evening: true },
    thursday: { morning: true, afternoon: true, evening: true },
    friday: { morning: true, afternoon: true, evening: true },
    saturday: { morning: true, afternoon: false, evening: false },
    sunday: { morning: false, afternoon: false, evening: true },
  },
  preferences: {
    sessionDuration: 1.5,
    breakTime: 15,
    maxSessionsPerDay: 4,
    priorityStrategy: 'balanced'
  }
};

// Action types
type PlannerAction =
  | { type: 'ADD_SUBJECT'; payload: Omit<Subject, 'id' | 'topics' | 'exams'> }
  | { type: 'UPDATE_SUBJECT'; payload: Partial<Subject> & { id: string } }
  | { type: 'DELETE_SUBJECT'; payload: { subjectId: string } }
  | { 
      type: 'ADD_TOPIC'; 
      payload: { 
        subjectId: string;
        name: string;
        estimatedHours: number;
        difficulty: number;
      } 
    }
  | { 
      type: 'DELETE_TOPIC'; 
      payload: { 
        subjectId: string;
        topicId: string;
      } 
    }
  | { 
      type: 'ADD_EXAM'; 
      payload: { 
        subjectId: string;
        name: string;
        date: string;
        weight: number;
      } 
    }
  | { 
      type: 'DELETE_EXAM'; 
      payload: { 
        subjectId: string;
        examId: string;
      } 
    }
  | { type: 'SET_SCHEDULE'; payload: DaySchedule[] }
  | { 
      type: 'TOGGLE_SESSION_COMPLETE'; 
      payload: { 
        dayId: string;
        sessionId: string;
      } 
    }
  | { 
      type: 'UPDATE_AVAILABILITY'; 
      payload: { 
        day: string;
        timeSlot: string;
        value: boolean;
      } 
    }
  | { 
      type: 'UPDATE_PREFERENCES'; 
      payload: Partial<Preferences>
    }
  | { type: 'RESET_DATA' };

// Reducer
const plannerReducer = (state: PlannerState, action: PlannerAction): PlannerState => {
  switch (action.type) {
    case 'ADD_SUBJECT':
      return {
        ...state,
        subjects: [
          ...state.subjects,
          {
            id: uuidv4(),
            name: action.payload.name,
            priority: action.payload.priority,
            color: action.payload.color,
            topics: [],
            exams: []
          }
        ]
      };
      
    case 'UPDATE_SUBJECT':
      return {
        ...state,
        subjects: state.subjects.map(subject => 
          subject.id === action.payload.id
            ? { ...subject, ...action.payload }
            : subject
        )
      };
      
    case 'DELETE_SUBJECT':
      return {
        ...state,
        subjects: state.subjects.filter(
          subject => subject.id !== action.payload.subjectId
        )
      };
      
    case 'ADD_TOPIC':
      return {
        ...state,
        subjects: state.subjects.map(subject => 
          subject.id === action.payload.subjectId
            ? { 
                ...subject, 
                topics: [
                  ...subject.topics,
                  {
                    id: uuidv4(),
                    name: action.payload.name,
                    estimatedHours: action.payload.estimatedHours,
                    difficulty: action.payload.difficulty
                  }
                ]
              }
            : subject
        )
      };
      
    case 'DELETE_TOPIC':
      return {
        ...state,
        subjects: state.subjects.map(subject => 
          subject.id === action.payload.subjectId
            ? { 
                ...subject, 
                topics: subject.topics.filter(
                  topic => topic.id !== action.payload.topicId
                )
              }
            : subject
        )
      };
      
    case 'ADD_EXAM':
      return {
        ...state,
        subjects: state.subjects.map(subject => 
          subject.id === action.payload.subjectId
            ? { 
                ...subject, 
                exams: [
                  ...subject.exams,
                  {
                    id: uuidv4(),
                    name: action.payload.name,
                    date: action.payload.date,
                    weight: action.payload.weight
                  }
                ]
              }
            : subject
        )
      };
      
    case 'DELETE_EXAM':
      return {
        ...state,
        subjects: state.subjects.map(subject => 
          subject.id === action.payload.subjectId
            ? { 
                ...subject, 
                exams: subject.exams.filter(
                  exam => exam.id !== action.payload.examId
                )
              }
            : subject
        )
      };
      
    case 'SET_SCHEDULE':
      return {
        ...state,
        schedule: action.payload
      };
      
    case 'TOGGLE_SESSION_COMPLETE':
      return {
        ...state,
        schedule: state.schedule.map(day => 
          day.id === action.payload.dayId
            ? { 
                ...day, 
                sessions: day.sessions.map(session => 
                  session.id === action.payload.sessionId
                    ? { ...session, completed: !session.completed }
                    : session
                )
              }
            : day
        )
      };
      
    case 'UPDATE_AVAILABILITY':
      return {
        ...state,
        availability: {
          ...state.availability,
          [action.payload.day]: {
            ...state.availability[action.payload.day],
            [action.payload.timeSlot]: action.payload.value
          }
        }
      };
      
    case 'UPDATE_PREFERENCES':
      return {
        ...state,
        preferences: {
          ...state.preferences,
          ...action.payload
        }
      };
      
    case 'RESET_DATA':
      return {
        ...initialState,
        // Keep the current availability and preferences
        availability: state.availability,
        preferences: state.preferences
      };
      
    default:
      return state;
  }
};

// Context
interface PlannerContextType {
  state: PlannerState;
  dispatch: React.Dispatch<PlannerAction>;
}

const PlannerContext = createContext<PlannerContextType | undefined>(undefined);

// Provider
export const PlannerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Try to load state from localStorage
  const loadState = (): PlannerState => {
    try {
      const savedState = localStorage.getItem('studyPlannerState');
      if (savedState) {
        return JSON.parse(savedState);
      }
    } catch (error) {
      console.error('Error loading state from localStorage:', error);
    }
    return initialState;
  };
  
  const [state, dispatch] = useReducer(plannerReducer, loadState());
  
  // Save state to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('studyPlannerState', JSON.stringify(state));
    } catch (error) {
      console.error('Error saving state to localStorage:', error);
    }
  }, [state]);
  
  return (
    <PlannerContext.Provider value={{ state, dispatch }}>
      {children}
    </PlannerContext.Provider>
  );
};

// Hook
export const usePlanner = (): PlannerContextType => {
  const context = useContext(PlannerContext);
  if (context === undefined) {
    throw new Error('usePlanner must be used within a PlannerProvider');
  }
  return context;
};