import React from 'react';
import { Calendar, Clock, BookOpen, AlertTriangle } from 'lucide-react';
import { usePlanner } from '../context/PlannerContext';
import TodaySchedule from '../components/dashboard/TodaySchedule';
import UpcomingExams from '../components/dashboard/UpcomingExams';
import SubjectProgress from '../components/dashboard/SubjectProgress';
import WeeklyOverview from '../components/dashboard/WeeklyOverview';

const Dashboard: React.FC = () => {
  const { state } = usePlanner();
  
  // Calculate total study hours planned
  const totalHoursPlanned = state.schedule
    .flatMap(day => day.sessions)
    .reduce((total, session) => total + session.duration, 0);
  
  // Count upcoming exams in the next 7 days
  const upcomingExamsCount = state.subjects
    .flatMap(subject => subject.exams)
    .filter(exam => {
      const examDate = new Date(exam.date);
      const today = new Date();
      const diffDays = Math.ceil((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 7;
    }).length;
  
  // Count total subjects
  const totalSubjects = state.subjects.length;
  
  // Calculate today's study hours
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
  const todaySchedule = state.schedule.find(day => day.day.toLowerCase() === today);
  const todayHours = todaySchedule 
    ? todaySchedule.sessions.reduce((total, session) => total + session.duration, 0)
    : 0;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6 flex items-center">
          <div className="rounded-full bg-blue-100 p-3 mr-4">
            <Clock className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Today's Study</p>
            <p className="text-2xl font-semibold text-gray-900">{todayHours} hours</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 flex items-center">
          <div className="rounded-full bg-purple-100 p-3 mr-4">
            <BookOpen className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Subjects</p>
            <p className="text-2xl font-semibold text-gray-900">{totalSubjects}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 flex items-center">
          <div className="rounded-full bg-green-100 p-3 mr-4">
            <Calendar className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Weekly Hours</p>
            <p className="text-2xl font-semibold text-gray-900">{totalHoursPlanned}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 flex items-center">
          <div className="rounded-full bg-amber-100 p-3 mr-4">
            <AlertTriangle className="h-6 w-6 text-amber-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Upcoming Exams</p>
            <p className="text-2xl font-semibold text-gray-900">{upcomingExamsCount}</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TodaySchedule />
        </div>
        <div>
          <UpcomingExams />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <WeeklyOverview />
        </div>
        <div>
          <SubjectProgress />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;