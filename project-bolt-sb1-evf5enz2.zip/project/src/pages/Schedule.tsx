import React, { useState } from 'react';
import { usePlanner } from '../context/PlannerContext';
import CalendarView from '../components/schedule/CalendarView';
import ListScheduleView from '../components/schedule/ListScheduleView';
import { Calendar, List, RefreshCw } from 'lucide-react';
import { generateSchedule } from '../utils/scheduleGenerator';

const Schedule: React.FC = () => {
  const { state, dispatch } = usePlanner();
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateSchedule = () => {
    setIsGenerating(true);
    
    // Simulate a loading state for the schedule generation
    setTimeout(() => {
      const generatedSchedule = generateSchedule(state.subjects, state.availability);
      dispatch({ type: 'SET_SCHEDULE', payload: generatedSchedule });
      setIsGenerating(false);
    }, 1500);
  };

  const noSubjectsOrExams = 
    state.subjects.length === 0 || 
    state.subjects.every(subject => subject.exams.length === 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Study Schedule</h1>
        
        <div className="flex space-x-4">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setViewMode('calendar')}
              className={`relative inline-flex items-center px-4 py-2 rounded-l-md border border-gray-300 text-sm font-medium ${
                viewMode === 'calendar'
                  ? 'z-10 bg-indigo-50 border-indigo-500 text-indigo-600'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Calendar className="h-4 w-4 mr-2" />
              Calendar
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`relative -ml-px inline-flex items-center px-4 py-2 rounded-r-md border border-gray-300 text-sm font-medium ${
                viewMode === 'list'
                  ? 'z-10 bg-indigo-50 border-indigo-500 text-indigo-600'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <List className="h-4 w-4 mr-2" />
              List
            </button>
          </div>
          
          <button
            onClick={handleGenerateSchedule}
            disabled={noSubjectsOrExams || isGenerating}
            className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white
              ${
                noSubjectsOrExams || isGenerating
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
              }`}
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Generate Schedule
              </>
            )}
          </button>
        </div>
      </div>

      {noSubjectsOrExams ? (
        <div className="bg-yellow-50 p-4 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">You need subjects with exams</h3>
              <div className="mt-2 text-sm text-yellow-700">
                <p>
                  Please add subjects with exam dates before generating a study schedule.
                  This will allow the algorithm to prioritize your study sessions effectively.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        viewMode === 'calendar' ? <CalendarView /> : <ListScheduleView />
      )}
    </div>
  );
};

export default Schedule;