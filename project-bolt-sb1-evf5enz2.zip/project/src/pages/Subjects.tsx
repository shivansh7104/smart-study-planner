import React, { useState } from 'react';
import { Plus, Edit2, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { usePlanner } from '../context/PlannerContext';
import SubjectForm from '../components/subjects/SubjectForm';
import ExamForm from '../components/subjects/ExamForm';
import TopicForm from '../components/subjects/TopicForm';

const Subjects: React.FC = () => {
  const { state, dispatch } = usePlanner();
  const [showSubjectForm, setShowSubjectForm] = useState(false);
  const [showExamForm, setShowExamForm] = useState<string | null>(null);
  const [showTopicForm, setShowTopicForm] = useState<string | null>(null);
  const [expandedSubject, setExpandedSubject] = useState<string | null>(null);
  const [editingSubject, setEditingSubject] = useState<string | null>(null);

  const toggleSubjectExpand = (subjectId: string) => {
    setExpandedSubject(expandedSubject === subjectId ? null : subjectId);
  };

  const handleDeleteSubject = (subjectId: string) => {
    if (window.confirm("Are you sure you want to delete this subject? This action cannot be undone.")) {
      dispatch({ type: 'DELETE_SUBJECT', payload: { subjectId } });
    }
  };

  const handleDeleteTopic = (subjectId: string, topicId: string) => {
    if (window.confirm("Are you sure you want to delete this topic?")) {
      dispatch({ 
        type: 'DELETE_TOPIC', 
        payload: { subjectId, topicId } 
      });
    }
  };

  const handleDeleteExam = (subjectId: string, examId: string) => {
    if (window.confirm("Are you sure you want to delete this exam?")) {
      dispatch({ 
        type: 'DELETE_EXAM', 
        payload: { subjectId, examId } 
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Subjects</h1>
        <button
          onClick={() => setShowSubjectForm(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Subject
        </button>
      </div>

      {showSubjectForm && (
        <SubjectForm 
          onClose={() => setShowSubjectForm(false)}
          editingId={editingSubject}
          onDone={() => {
            setShowSubjectForm(false);
            setEditingSubject(null);
          }}
        />
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {state.subjects.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            <p>No subjects added yet. Click the "Add Subject" button to get started.</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {state.subjects.map((subject) => (
              <li key={subject.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div 
                      className="flex items-center cursor-pointer" 
                      onClick={() => toggleSubjectExpand(subject.id)}
                    >
                      {expandedSubject === subject.id ? 
                        <ChevronUp className="h-5 w-5 text-gray-400 mr-2" /> : 
                        <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
                      }
                      <p className="text-lg font-medium text-indigo-600 truncate">{subject.name}</p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setEditingSubject(subject.id);
                          setShowSubjectForm(true);
                        }}
                        className="p-1 text-gray-500 hover:text-indigo-600 transition"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteSubject(subject.id)}
                        className="p-1 text-gray-500 hover:text-red-600 transition"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-gray-500">
                    <p>Priority: {subject.priority}</p>
                  </div>

                  {expandedSubject === subject.id && (
                    <div className="mt-4">
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="text-sm font-medium text-gray-700">Topics</h3>
                          <button
                            onClick={() => setShowTopicForm(subject.id)}
                            className="inline-flex items-center px-2 py-1 text-xs font-medium rounded text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Add Topic
                          </button>
                        </div>
                        
                        {showTopicForm === subject.id && (
                          <TopicForm 
                            subjectId={subject.id} 
                            onClose={() => setShowTopicForm(null)} 
                          />
                        )}

                        {subject.topics.length === 0 ? (
                          <p className="text-xs text-gray-500">No topics added yet</p>
                        ) : (
                          <div className="bg-gray-50 rounded-md p-3">
                            <ul className="space-y-2">
                              {subject.topics.map((topic) => (
                                <li key={topic.id} className="flex justify-between items-center">
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">{topic.name}</p>
                                    <p className="text-xs text-gray-500">
                                      Estimated study time: {topic.estimatedHours} hours
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteTopic(subject.id, topic.id)}
                                    className="text-gray-400 hover:text-red-600"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="text-sm font-medium text-gray-700">Exams</h3>
                          <button
                            onClick={() => setShowExamForm(subject.id)}
                            className="inline-flex items-center px-2 py-1 text-xs font-medium rounded text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Add Exam
                          </button>
                        </div>
                        
                        {showExamForm === subject.id && (
                          <ExamForm 
                            subjectId={subject.id} 
                            onClose={() => setShowExamForm(null)} 
                          />
                        )}

                        {subject.exams.length === 0 ? (
                          <p className="text-xs text-gray-500">No exams added yet</p>
                        ) : (
                          <div className="bg-gray-50 rounded-md p-3">
                            <ul className="space-y-2">
                              {subject.exams.map((exam) => (
                                <li key={exam.id} className="flex justify-between items-center">
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">{exam.name}</p>
                                    <p className="text-xs text-gray-500">
                                      Date: {new Date(exam.date).toLocaleDateString()}
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteExam(subject.id, exam.id)}
                                    className="text-gray-400 hover:text-red-600"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Subjects;