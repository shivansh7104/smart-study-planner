import { v4 as uuidv4 } from 'uuid';
import { Subject, DaySchedule, Availability } from '../context/PlannerContext';

// Time slot definitions
const timeSlots = {
  morning: {
    start: '08:00',
    end: '12:00',
  },
  afternoon: {
    start: '13:00',
    end: '17:00',
  },
  evening: {
    start: '18:00',
    end: '21:00',
  },
};

// Generate a schedule based on subjects, exams, and availability
export function generateSchedule(subjects: Subject[], availability: Availability): DaySchedule[] {
  // Initialize empty schedule for each day of the week
  const daysOfWeek = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];
  
  const schedule: DaySchedule[] = daysOfWeek.map(day => ({
    id: uuidv4(),
    day,
    sessions: [],
  }));
  
  // Skip if no subjects with exams
  if (subjects.length === 0 || subjects.every(subject => subject.exams.length === 0)) {
    return schedule;
  }
  
  // Calculate study priority for each subject based on exam dates
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const subjectsWithPriority = subjects.map(subject => {
    // Find the closest exam
    const closestExam = subject.exams
      .filter(exam => new Date(exam.date) >= today)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];
    
    let examPriority = 1;
    
    if (closestExam) {
      const examDate = new Date(closestExam.date);
      const daysUntilExam = Math.ceil(
        (examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      // Higher priority for closer exams
      if (daysUntilExam <= 3) {
        examPriority = 5;
      } else if (daysUntilExam <= 7) {
        examPriority = 4;
      } else if (daysUntilExam <= 14) {
        examPriority = 3;
      } else if (daysUntilExam <= 30) {
        examPriority = 2;
      }
      
      // Adjust based on exam weight/importance
      examPriority += closestExam.weight - 1;
    }
    
    // Combine subject priority and exam priority
    const combinedPriority = (subject.priority + examPriority) / 2;
    
    return {
      ...subject,
      examPriority,
      combinedPriority,
      closestExamDate: closestExam ? new Date(closestExam.date) : null,
    };
  });
  
  // Sort subjects by priority (highest first)
  const sortedSubjects = [...subjectsWithPriority].sort(
    (a, b) => b.combinedPriority - a.combinedPriority
  );
  
  // Distribute study sessions across the week
  daysOfWeek.forEach((day, dayIndex) => {
    const dayLower = day.toLowerCase();
    const availableTimeSlots = Object.keys(timeSlots).filter(
      slot => availability[dayLower]?.[slot as keyof typeof timeSlots]
    );
    
    if (availableTimeSlots.length === 0) return;
    
    // Assign subjects to this day based on priority
    availableTimeSlots.forEach(slot => {
      const timeSlot = timeSlots[slot as keyof typeof timeSlots];
      
      // Choose subject based on priority and rotation
      // Simple rotation: (dayIndex + slotIndex) % subjects.length
      const slotIndex = slot === 'morning' ? 0 : slot === 'afternoon' ? 1 : 2;
      const subjectIndex = (dayIndex + slotIndex) % sortedSubjects.length;
      const subject = sortedSubjects[subjectIndex];
      
      if (subject && subject.topics.length > 0) {
        // Choose a topic (for simplicity, just pick the first one)
        // In a real app, we would need more sophisticated rotation
        const topic = subject.topics[0];
        
        // Create a study session
        const session = {
          id: uuidv4(),
          subjectId: subject.id,
          topicId: topic.id,
          startTime: timeSlot.start,
          endTime: timeSlot.end,
          duration: 2, // Default 2 hours
          completed: false,
        };
        
        // Add to schedule
        const daySchedule = schedule.find(d => d.day === day);
        if (daySchedule) {
          daySchedule.sessions.push(session);
        }
      }
    });
  });
  
  return schedule;
}